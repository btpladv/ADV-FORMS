The CSV files in this folder contain the names of the images that were used in the sets of the same name to train and validate the document layout analysis.
